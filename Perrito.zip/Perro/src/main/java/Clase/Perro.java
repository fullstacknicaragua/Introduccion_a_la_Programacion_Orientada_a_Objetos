package Clase;

public class Perro {
/*Segun el ejemplo que habiamos mencionado del perrito vamos a crear los atributos que serian las propiedades del objeto*/
    
    public String nombre;
    public String raza;
    public String altura;
    public int edad;
    
    // Metodos de la clase que serian las operaciones propias de la clase que se definio //
 
    public String comer (String carne)
    {
     return "El es: " + nombre + "y mide" + altura + " y su edad es de "+ edad + "lo que come es" + carne; 
    }
    
    public void dormir ()
    {
    
    }
    
    public void ladrar ()
            
    {
    
    }
    
    public void jugar ()
            
    {
    
    }
    
    //Ahora usaremos los CONSTRUCTORES en esta misma clase dentro del programa ya para trabajarlo//
    
    public Perro ()
    {
        
    }
    public Perro (String nombre, String raza, String altura, int edad)
    {
    this.nombre=nombre;
    this.raza=raza;
    this.altura=altura;
    this.edad=edad;
    }
}